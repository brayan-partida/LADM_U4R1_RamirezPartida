package mx.edu.ittepic.ladm_u4p1_ramirezpartida


import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    val siLecturaContactos=18
    val siRegistroLlamadas = 2
    val siLLamadas = 4
    val siEstado = 8

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if(ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,
                    arrayOf(android.Manifest.permission.READ_CONTACTS),siLecturaContactos)
        }
        if (ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,
                    arrayOf(android.Manifest.permission.READ_CALL_LOG),siRegistroLlamadas)
        }

        if (ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,
                    arrayOf(android.Manifest.permission.ANSWER_PHONE_CALLS),siLLamadas)
        }

        if (ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this,android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.READ_PHONE_STATE, android.Manifest.permission.CALL_PHONE),siEstado)
        }
        button.setOnClickListener {
            cargarListaContactos()

        }
    }

    fun cargarListaContactos(){
        var resultado=""
        val cursorContactos=contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,null,null,null,null)
        if(cursorContactos!!.moveToFirst()){
            do{
                var idContacto=cursorContactos.getInt(
                        cursorContactos.getColumnIndex(ContactsContract.Contacts._ID))
                var nombreContacto =cursorContactos.getString(
                        cursorContactos.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))
                var telefonosContactos=""
                if(cursorContactos.getInt(
                                cursorContactos.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))>0){
                    var cursorCel=contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            arrayOf<String>(idContacto.toString()), null)

                    while (cursorCel!!.moveToNext()){
                        telefonosContactos+=cursorCel.getString(cursorCel.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))+
                                "\n"
                    }
                    cursorCel.close()
                }
                resultado+= "ID: "+idContacto+"\nNombre: "+nombreContacto+"\nTelefonos:\n"+
                        telefonosContactos+"\n------------\n"
            }while(cursorContactos.moveToNext())
            textView.setText(resultado)
        }else{
            resultado="CONTACTOS: \nNO HAY CONTACTOS GUARDADOS"
        }
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode==siLecturaContactos){
            Toast.makeText(this,"Permiso otorgado",Toast.LENGTH_SHORT).show()
        }
    }
}


