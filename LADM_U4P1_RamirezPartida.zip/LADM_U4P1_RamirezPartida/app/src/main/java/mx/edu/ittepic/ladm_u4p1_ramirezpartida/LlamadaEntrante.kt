package mx.edu.ittepic.ladm_u4p1_ramirezpartida

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

class LlamadaEntrante: BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        try{

            val estado =intent!!.getStringExtra(TelephonyManager.EXTRA_STATE)
            val contacto =intent!!.extras!!.getString(TelephonyManager.EXTRA_INCOMING_NUMBER)

            if(estado.equals(TelephonyManager.EXTRA_STATE_RINGING)){
                try{
                    if(!estaEnContactos(contacto!!,context!!)){
                        colgarLlamada(context!!)
                    }
                } catch (e : Exception){
                    e.printStackTrace()
                }
            }
        } catch (e : Exception){
            e.printStackTrace()
        }
    }
    fun estaEnContactos(contacto : String, context : Context) : Boolean {
        val contentResolver = context.contentResolver
        val cursorContactos = contentResolver.query(ContactsContract.Contacts.CONTENT_URI,null,null,null,null)

        if(cursorContactos!!.moveToFirst()){
            do {
                var idContacto =
                    cursorContactos.getString(cursorContactos.getColumnIndex(ContactsContract.Contacts._ID))

                if(cursorContactos.getInt(cursorContactos.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))>0){
                    var cursorCel = contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                        arrayOf<String>(idContacto.toString()),null)
                    while (cursorCel!!.moveToNext()){
                        if(contacto == cursorCel.getString(cursorCel.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)).toString()){
                            return true
                        }
                    }
                    cursorCel.close()
                } else {

                }
            }while (cursorContactos.moveToNext())

        } else{
        }
        return false
    }

    fun colgarLlamada(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            if (telecomManager != null && ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ANSWER_PHONE_CALLS
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                telecomManager.endCall()
                return true
            }
        }
        return false
    }

}